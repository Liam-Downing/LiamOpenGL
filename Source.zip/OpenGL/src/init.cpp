#include "init.h"

void initGLFW() {
				glfwInit();
				glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
				glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
				glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
}

GLFWwindow* createWindow() {
				GLFWmonitor* monitor = glfwGetPrimaryMonitor();
				const GLFWvidmode* mode = glfwGetVideoMode(monitor);
				GLFWwindow* window = glfwCreateWindow(mode->width, mode->height, "OpenGL", monitor, NULL);
				
				if (window == NULL) {
								glfwTerminate();
								std::cout << "ERROR Failed To Create GLFWwindow!" << std::endl;
								std::cin.get();
								return NULL;
				}

				return window;
}

int initGLAD() {
				if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
				{
				    std::cout << "Failed to initialize GLAD" << std::endl;
				    return -1;
				} 
				return 1;
}
