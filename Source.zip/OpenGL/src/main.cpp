#include "init.h"
#include <iostream>
#include <ostream>
#include <string>

static GLuint compileShader(const std::string& shaderSource, GLenum type) {
				GLuint id = glCreateShader(type);

				const char* src = shaderSource.c_str();
				glShaderSource(id, 1, &src, nullptr);
				glCompileShader(id);
				
				int result;
				glGetShaderiv(id, GL_COMPILE_STATUS, &result);

				if (result == GL_FALSE) {
								int length;
								glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
								char* message = (char*)alloca(length * sizeof(char));
								glGetShaderInfoLog(id, length, &length, message);
								std::cout << "Failed to compile" << (type == GL_VERTEX_SHADER ? "vertex" : "fragment") << "shader!" << std::endl;
								std::cout << message << std::endl;
								glDeleteShader(id);
								return 0;
				}

				return id;
}

static GLuint createShader(const std::string& vertexShader, const std::string& fragmentShader) {
				GLuint program = glCreateProgram();
				GLuint vs = compileShader(vertexShader, GL_VERTEX_SHADER);
				GLuint fs = compileShader(fragmentShader, GL_FRAGMENT_SHADER);

				glAttachShader(program, vs);
				glAttachShader(program, fs);
				glLinkProgram(program);
				glValidateProgram(program);

				glDeleteShader(vs);
				glDeleteShader(fs);
				return program;
}

int main() {
				initGLFW();
				GLFWwindow* window = createWindow();
				glfwMakeContextCurrent(window);
				initGLAD();

				float positions[6] = {
							-0.5, -0.5, 
							 0.5, -0.5,
							 0.0,  0.5
				};

				GLFWmonitor* monitor = glfwGetPrimaryMonitor();
				const GLFWvidmode* mode = glfwGetVideoMode(monitor);
				glViewport(0, 0, mode->width, mode->height);
				std::cout << glGetString(GL_VERSION) << std::endl;

				GLuint VAO;
				glGenVertexArrays(1, &VAO);
				glBindVertexArray(VAO);

				unsigned int buffer;
				glGenBuffers(1, &buffer);
				glBindBuffer(GL_ARRAY_BUFFER, buffer);
				glBufferData(GL_ARRAY_BUFFER, 6 * sizeof(float), positions, GL_STATIC_DRAW);

				glEnableVertexAttribArray(0);
				glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(float) * 2, 0);

				std::string fragmentShader = "#version 330 core\n"
								"\n"
								"layout(location = 0) out vec4 color;\n"
								"void main()\n"
								"{\n"
								"		color = vec4(0.94, 0.722, 0.627, 1.0);\n"
								"}\n";

				std::string vertexShader = "#version 330 core\n"
								"\n"
								"layout(location = 0) in vec4 position;\n"
								"void main()\n"
								"{\n"
								"		gl_Position = position;\n"
								"}\n";

				GLuint shader = createShader(vertexShader, fragmentShader); 
				glUseProgram(shader);

				while (!glfwWindowShouldClose(window)) {
								glClear(GL_COLOR_BUFFER_BIT);
								glClearColor(0.0, 0.5, 1.0, 1.0);
								glDrawArrays(GL_TRIANGLES, 0, 3);

								glfwSwapBuffers(window);

								glfwPollEvents();
				}

				glfwTerminate();
				return 0;
}
