#ifndef INIT_H
#define INIT_H
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
void initGLFW();
int initGLAD();
GLFWwindow* createWindow();
#endif
