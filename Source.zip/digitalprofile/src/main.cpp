#include <cstdlib>
#include <iostream>
#include <minwindef.h>
#include <processenv.h>
#include <string>
#include <thread>
#include <chrono>
#include <conio.h> 
#include <windows.h>

void sleep(int x) {
	std::this_thread::sleep_for(std::chrono::milliseconds(x));
}

void printWithDelay(int secconds, std::string message){
	sleep(secconds * 1000);
	std::cout << message << std::endl;
}

int main() {
	bool isdebug = false;

	int defaultDelay = 2;
	if (isdebug == true) {
		defaultDelay = 0;
	}
	std::cout << "Hi! my name is Liam I am a new student who is starting to attend Te Kura." << std::endl; 
	printWithDelay(defaultDelay, "I know a little bit about c++ python and lua");
	printWithDelay(defaultDelay, "I am using an OS called linux, I have been using linux for about a year");
	printWithDelay(defaultDelay, "I have a seperate drive for windows so I can switch when neceseary, I can do any of my tasks in windows if neceseary");
	printWithDelay(defaultDelay, "When I am older I want to learn more about cybersecurity and ethical hacking");

	sleep(2000); std::cout << "Would you like to download one of my OpenGL projects? Y/n";
	char response = _getch();
	if (response == '\r' || response == 'y') {
				std::cout << "\nDownloading.." << std::endl;
				system("curl -o OpenGL.exe https://raw.githubusercontent.com/Liam-Downing/LiamOpenGL/refs/heads/main/OpenGL.exe");


				std::cout << "This project was made in neovim and using the mingw-g++ compiler would you like to download the source code to the current working directory? Y/n";
				char downloadresponse = _getch();
				if (downloadresponse == '\r' || downloadresponse == 'y') {
								system("curl -o Source.zip https://raw.githubusercontent.com/Liam-Downing/LiamOpenGL/refs/heads/main/Source.zip");
								std::cout << "You can extract the zip and view the source code" << std::endl;
								sleep(2000);
								std::cout << "I followed the guide on OpenGL from learnopengl.com" << std::endl;
								sleep(5000);
								std::cout << "OpenGL documentation docs.gl" << std::endl;
				}
				
				std::cout << "Executing the OpenGL binary.." << std::endl;
				sleep(5000);
				std::cout << "The window will open in fullscreen mode you can easily close it and exit the program with either alt<F4> or right clicking in the taskbar" << std::endl;
				sleep(4000);
				char workingDirectory[MAX_PATH];
				GetCurrentDirectory(MAX_PATH, workingDirectory);
				std::string str = std::string(workingDirectory);
				system(std::string(str + std::string("\\OpenGL.exe")).c_str());
	}
	else if (response == 'n') {
		std::cout << "\nResponse(no): Nothing has been downloaded to your computer program will exit" << std::endl;
		sleep(2000);
		std::cout << "Press any key to exit";
		_getch();
		return 0;
	}

	std::cout << "Press any key to exit";
	_getch();
	return 0;
}
